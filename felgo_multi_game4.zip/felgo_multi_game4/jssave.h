#ifndef JSSAVE_H
#define JSSAVE_H

#include<QFile>
#include<QJsonObject>
#include<QJsonDocument>
#include<QTextStream>
#include<QString>
#include<QDebug>

class Data : public QObject
{
    Q_OBJECT
    //Q_PROPERTY(int highscore READ highscore WRITE sethighScore NOTIFY highscoreChanged)
signals:
    //void highscoreChanged();
public:
        explicit Data(QObject *parent = nullptr);
        //Q_INVOKABLE void sethighScore(int score);
        Q_INVOKABLE int read1();
        Q_INVOKABLE void write1(int json)const;
        Q_INVOKABLE int read2();
        Q_INVOKABLE void write2(int json)const;
        Q_INVOKABLE int read3();
        Q_INVOKABLE void write3(int json)const;
       // Q_INVOKABLE void saveData();
        //Q_INVOKABLE bool loadData();

};
#endif // JSSAVE_H

