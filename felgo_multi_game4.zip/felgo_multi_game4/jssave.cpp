#include"jssave.h"
#include<QFile>
#include<QJsonObject>
#include<QJsonDocument>
#include<QTextStream>
#include<QString>
#include<QDebug>

Data::Data(QObject *parent):QObject (parent){

}

int Data::read1(){
    int a;
   // QString s;
    int max=0;
    QFile file("1.txt");
    if(!file.open(QIODevice::ReadOnly|QIODevice::Text)){

            qDebug()<<"error1"<<endl;
    }
   //file.readAll();
    while (!file.atEnd()) {
        QByteArray line = file.readLine();
        QString str(line);
        QString json(str);
        QJsonParseError jsonerror;
        QJsonDocument doc = QJsonDocument::fromJson(json.toLatin1(),&jsonerror);
        if(!doc.isNull() && jsonerror.error == QJsonParseError::NoError){
            if(doc.isObject()){
                QJsonObject object = doc.object();
                QStringList list = object.keys();
                QJsonObject::iterator it = object.begin();
                a=object["data"].toInt();
               // qDebug()<<a<<endl;
                if(max<a)
                    max=a;

            }
            else {
                qDebug()<<"error"<<endl;
            }

        }
        else {
            qDebug()<<"error"<<endl;
        }

    }
    qDebug()<<max;
    return max;
}
void Data::write1(int json)const{
    QJsonObject data;
    data.insert("data",json);
    QJsonDocument datadoc;
    datadoc.setObject(data);
    QByteArray bte_array=datadoc.toJson(QJsonDocument::Compact);
    QString json_st(bte_array);
    QTextStream(stdout)<<json_st;
    QFile file("1.txt");
    if(!file.open(QIODevice::Append|QIODevice::ReadWrite))
        qDebug()<<"e";
    QTextStream in(&file);
    in<<json_st<<endl;
    file.close();
}
int Data::read2(){
    int a;
   // QString s;
    int max=0;
    QFile file("2.txt");
    if(!file.open(QIODevice::ReadOnly|QIODevice::Text)){

            qDebug()<<"error1"<<endl;
    }
   //file.readAll();
    while (!file.atEnd()) {
        QByteArray line = file.readLine();
        QString str(line);
        QString json(str);
        QJsonParseError jsonerror;
        QJsonDocument doc = QJsonDocument::fromJson(json.toLatin1(),&jsonerror);
        if(!doc.isNull() && jsonerror.error == QJsonParseError::NoError){
            if(doc.isObject()){
                QJsonObject object = doc.object();
                QStringList list = object.keys();
                QJsonObject::iterator it = object.begin();
                a=object["data"].toInt();
               // qDebug()<<a<<endl;
                if(max<a)
                    max=a;

            }
            else {
                qDebug()<<"error"<<endl;
            }

        }
        else {
            qDebug()<<"error"<<endl;
        }

    }
    qDebug()<<max;
    return max;
}
void Data::write2(int json)const{
    QJsonObject data;
    data.insert("data",json);
    QJsonDocument datadoc;
    datadoc.setObject(data);
    QByteArray bte_array=datadoc.toJson(QJsonDocument::Compact);
    QString json_st(bte_array);
    QTextStream(stdout)<<json_st;
    QFile file("2.txt");
    if(!file.open(QIODevice::Append|QIODevice::ReadWrite))
        qDebug()<<"e";
    QTextStream in(&file);
    in<<json_st<<endl;
    file.close();
}
int Data::read3(){
    int a;
   // QString s;
    int max=0;
    QFile file("3.txt");
    if(!file.open(QIODevice::ReadOnly|QIODevice::Text)){

            qDebug()<<"error1"<<endl;
    }
   //file.readAll();
    while (!file.atEnd()) {
        QByteArray line = file.readLine();
        QString str(line);
        QString json(str);
        QJsonParseError jsonerror;
        QJsonDocument doc = QJsonDocument::fromJson(json.toLatin1(),&jsonerror);
        if(!doc.isNull() && jsonerror.error == QJsonParseError::NoError){
            if(doc.isObject()){
                QJsonObject object = doc.object();
                QStringList list = object.keys();
                QJsonObject::iterator it = object.begin();
                a=object["data"].toInt();
               // qDebug()<<a<<endl;
                if(max<a)
                    max=a;

            }
            else {
                qDebug()<<"error"<<endl;
            }

        }
        else {
            qDebug()<<"error"<<endl;
        }

    }
    qDebug()<<max;
    return max;
}
void Data::write3(int json)const{
    QJsonObject data;
    data.insert("data",json);
    QJsonDocument datadoc;
    datadoc.setObject(data);
    QByteArray bte_array=datadoc.toJson(QJsonDocument::Compact);
    QString json_st(bte_array);
    QTextStream(stdout)<<json_st;
    QFile file("3.txt");
    if(!file.open(QIODevice::Append|QIODevice::ReadWrite))
        qDebug()<<"e";
    QTextStream in(&file);
    in<<json_st<<endl;
    file.close();
}
